from pydantic_settings import BaseSettings


class Settings(BaseSettings):
    """应用配置，支持 .env 文件和环境变量"""

    APP_NAME: str = "MistakesMaster"
    DEBUG: bool = False

    # 数据库（默认 MySQL，可选 SQLite / PostgreSQL）
    DATABASE_URL: str = "mysql+asyncmy://root:115900@localhost:3306/mistakes"

    # JWT
    JWT_SECRET_KEY: str = "change-me-to-a-random-secret-key"
    JWT_ALGORITHM: str = "HS256"
    JWT_ACCESS_TOKEN_EXPIRE_MINUTES: int = 1440  # 24 小时

    # 日志
    LOG_LEVEL: str = "INFO"
    LOG_DIR: str = "logs"
    LOG_BACKUP_COUNT: int = 30
    LOG_ERROR_BACKUP_COUNT: int = 90

    # Redis（可选）
    REDIS_URL: str = ""

    # 文件上传
    UPLOAD_DIR: str = "uploads"
    MAX_UPLOAD_SIZE: int = 5 * 1024 * 1024  # 5MB

    model_config = {"env_file": ".env", "env_file_encoding": "utf-8"}


settings = Settings()
