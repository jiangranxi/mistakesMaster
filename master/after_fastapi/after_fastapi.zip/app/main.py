import logging
from contextlib import asynccontextmanager
from pathlib import Path

from fastapi import FastAPI, Request
from fastapi.middleware.cors import CORSMiddleware
from fastapi.responses import JSONResponse
from fastapi.staticfiles import StaticFiles

from app.config import settings
from app.core.exceptions import AppException
from app.core.logging_config import setup_logging
from app.database import engine
from app.middleware.request_logging import RequestLoggingMiddleware
from app.models import Base
from app.routers import auth, books, member, messages, upload
from app.routers.teacher import classes, homework as t_homework, lesson_plans, review
from app.routers.student import classes as s_classes, homework as s_homework

logger = logging.getLogger(__name__)

@asynccontextmanager
async def lifespan(app: FastAPI):
    """应用生命周期 - 启动时自动建表"""
    logger.info("应用启动中...")
    async with engine.begin() as conn:
        await conn.run_sync(Base.metadata.create_all)
    logger.info("数据库表初始化完成")

    yield

    logger.info("应用关闭")

# 确保上传目录存在
Path(settings.UPLOAD_DIR).mkdir(parents=True, exist_ok=True)

# 初始化日志（必须在 FastAPI 实例化之前）
setup_logging()

app = FastAPI(
    title=settings.APP_NAME,
    version="1.0.0",
    lifespan=lifespan,
)

# 请求日志中间件（最外层，最先执行）
app.add_middleware(RequestLoggingMiddleware)

# CORS 中间件
app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],
    allow_methods=["*"],
    allow_headers=["*"],
)

# 注册路由
app.include_router(auth.router)

# 教师端
app.include_router(classes.router, prefix="/teacher")
app.include_router(t_homework.router, prefix="/teacher")
app.include_router(lesson_plans.router, prefix="/teacher")
app.include_router(review.router, prefix="/teacher")

# 学生端
app.include_router(s_classes.router, prefix="/student")
app.include_router(s_homework.router, prefix="/student")

# 通用模块
app.include_router(books.router)
app.include_router(member.router)
app.include_router(messages.router)
app.include_router(upload.router)

# 挂载静态文件（必须在路由注册之后）
app.mount("/static", StaticFiles(directory=settings.UPLOAD_DIR), name="static")


# 全局异常处理
@app.exception_handler(AppException)
async def app_exception_handler(request: Request, exc: AppException):
    return JSONResponse(
        status_code=exc.status_code,
        content={"message": exc.detail},
    )


@app.exception_handler(Exception)
async def global_exception_handler(request: Request, exc: Exception):
    logger.exception("未捕获异常: %s %s", request.method, request.url.path)
    return JSONResponse(
        status_code=500,
        content={"message": "服务器内部错误"},
    )


@app.get("/health")
async def health_check():
    """健康检查"""
    return {"status": "ok"}
